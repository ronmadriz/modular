<?
echo '<aside class="blog__side">'.PHP_EOL;
include (get_template_directory().'/views/components/navigation/categories.php');
include ('osha.php');
echo '</aside>'.PHP_EOL;
