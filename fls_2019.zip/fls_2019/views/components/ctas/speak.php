<?
// CTA Speak
echo (!empty(get_the_content())?'<section class="speak" id="speak"><div class="wrapper"><div class="speak__title"><span class="speak__title--text"><a class="speak__link" href="#cta_blue">Speak with a fall protection specialist <i class="speak__icon im im-angle-right-circle"></i></a></span></div></div></section>'.PHP_EOL:'');
