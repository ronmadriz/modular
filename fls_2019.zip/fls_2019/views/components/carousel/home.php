<?
echo '<section id="hero" class="hero">'.PHP_EOL;
echo do_shortcode("[rev_slider alias='basic-hero-collection1']");
echo '</section>'.PHP_EOL;
