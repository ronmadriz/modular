<?
$footer_form = get_theme_mod('footer_form');
echo '<section id="contactFormCTA" class="homeForm">'.PHP_EOL;
echo '<div class="wrapper">'.PHP_EOL;
echo (!empty($footer_form)?'<div class="homeForm__content">'.do_shortcode($footer_form).'</div>'.PHP_EOL:'');
echo '</div>'.PHP_EOL;
echo '</div>'.PHP_EOL;
echo '</div>'.PHP_EOL;
echo '</section>'.PHP_EOL;
