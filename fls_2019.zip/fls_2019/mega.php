<?php
/**
 * Template Name: Mega
 */
get_header();
echo '<section id="mega"></section>'.PHP_EOL;
get_footer();
