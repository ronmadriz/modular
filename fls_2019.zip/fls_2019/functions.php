<?php
require_once ('functions/scripts-styles.php');
require_once ('functions/reset.php');
require_once ('functions/includes.php');
require_once ('functions/backend.php');
require_once ('functions/breadcrumbs-functions.php');
require_once ('functions/menus.php');
require_once ('functions/class-wp-bootstrap-navwalker.php');
require_once ('functions/wp-bootstrap4.1-pagination.php');
require_once ('functions/FlsMain_Walker.php');
require_once ('functions/Footer_Walker.php');
require_once ('functions/Category_Walker.php');
require_once ('functions/Boiler_Walker.php');
require_once ('functions/Solutions_Walker.php');
require_once ('functions/social.php');
require_once ('functions/gallery.php');
require_once ('functions/custom-reviews.php');
require_once ('functions/lrm_code.php');
require_once ('functions/contact-form-7.php');
require_once ('functions/extras.php');
require_once ('functions/loadmore.php');
require_once ('functions/acf_icon_picker.php');
?>
