<?php
	echo do_shortcode('[contact-form-7 id="1116969" title="Sidebar Form"]');
?>
