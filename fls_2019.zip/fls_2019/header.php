<?php
include ('views/global/head/meta.php');
include ('views/global/head/head.php');
