<?php
include ('views/global/foot/foot.php');
